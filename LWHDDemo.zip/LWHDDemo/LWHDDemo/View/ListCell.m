//
//  ListCell.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ListCell.h"
@interface ListCell ()
@property(nonatomic,strong)UILabel *addressLB;
@property(nonatomic,strong)UILabel *NameLB;
@property(nonatomic,strong)UILabel *PhoneLB;
@property(nonatomic,strong)UILabel *LB;
@end
@implementation ListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}
- (void)updateAddress:(ZWListModel *)address{
    self.NameLB.text = address.cameraName;
    self.PhoneLB.text = @"在线";
    self.addressLB.text = @"查看";
    
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self zw_setupViews];
    }
    return self;
}
-(void)zw_setupViews{
    self.contentView.backgroundColor= [UIColor colorWithHexString:@"#ffffff"];
    [self.contentView addSubview:self.NameLB];
    [self.NameLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView.mas_left).with.mas_offset(15);
        make.top.mas_equalTo(self.contentView.mas_top).with.mas_offset(10);
        make.height.mas_equalTo(20);
    }];
    
    [self.contentView addSubview:self.PhoneLB];
    [self.PhoneLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView.mas_left).with.mas_offset(15);
        make.top.mas_equalTo(self.NameLB.mas_bottom).with.mas_offset(10);
        make.height.mas_equalTo(16);
    }];
    [self.contentView addSubview:self.addressLB];
    [self.addressLB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.contentView.mas_right).with.mas_offset(-15);
        make.centerY.mas_equalTo(self.contentView.mas_centerY);
        make.height.mas_equalTo(16);
    }];
}
-(UILabel *)addressLB{
    if (_addressLB == nil) {
        _addressLB = [[UILabel alloc]init];
        _addressLB.textAlignment =NSTextAlignmentLeft;
        _addressLB.font = [UIFont zwwNormalFont:12];
        _addressLB.textColor = [UIColor colorWithHexString:@"#999999"];
    }
    return _addressLB;
}
-(UILabel *)NameLB{
    if (_NameLB == nil) {
        _NameLB = [[UILabel alloc]init];
        _NameLB.textAlignment =NSTextAlignmentLeft;
        _NameLB.font = [UIFont zwwNormalFont:16];
        _NameLB.textColor = [UIColor colorWithHexString:@"#1B1B1B"];
    }
    return _NameLB;
}
-(UILabel *)LB{
    if (_LB == nil) {
        _LB = [[UILabel alloc]init];
        _LB.textAlignment =NSTextAlignmentCenter;
        _LB.font = [UIFont zwwNormalFont:16];
        _LB.textColor = [UIColor colorWithHexString:@"#1B1B1B"];
    }
    return _LB;
}
-(UILabel *)PhoneLB{
    if (_PhoneLB == nil) {
        _PhoneLB = [[UILabel alloc]init];
        _PhoneLB.textAlignment =NSTextAlignmentLeft;
        _PhoneLB.font = [UIFont zwwNormalFont:12];
        _PhoneLB.textColor = [UIColor colorWithHexString:@"#999999"];
    }
    return _PhoneLB;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
