//
//  ListCell.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZWListModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ListCell : UITableViewCell
- (void)updateAddress:(ZWListModel *)address;
@end

NS_ASSUME_NONNULL_END
