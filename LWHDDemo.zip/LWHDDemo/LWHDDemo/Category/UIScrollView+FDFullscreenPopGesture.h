



NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (FDFullscreenPopGesture)

@end

NS_ASSUME_NONNULL_END
