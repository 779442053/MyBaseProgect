//
//  AppDelegate.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+ZWAppDelegate.h"
#import<CoreTelephony/CTCellularData.h>
#import "ZWDataManager.h"
#import <AFNetworking/AFNetworking.h>

@interface AppDelegate ()
@property (strong,nonatomic) Reachability* reachablity;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self initUserManager];
    [self initWindow];
    if (__IPHONE_10_0) {
        self.reachablity = [Reachability reachabilityWithHostName:@"www.taobao.com"];
        [self.reachablity startNotifier];
        NetworkStatus status = [self.reachablity currentReachabilityStatus];
        [self monitorNetworkStatus:status];
        [self networkStatus:application didFinishLaunchingWithOptions:launchOptions];
    }else {
        //2.2已经开启网络权限 监听网络状态
        [self addReachabilityManager:application didFinishLaunchingWithOptions:launchOptions];
    }
    return YES;
}
- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    if (self.allowRotation) {
        return  UIInterfaceOrientationMaskAllButUpsideDown;
    }
    return UIInterfaceOrientationMaskPortrait;
}
- (void)applicationWillResignActive:(UIApplication *)application {
     ZWWLog(@"\n即将进入后台\n applicationWillResignActive")
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    [ZWDataManager saveUserData];
    //    清除角标
    [[UIApplication alloc] setApplicationIconBadgeNumber:0];
    ZWWLog(@"\n已经进入了后台\n applicationDidEnterBackground")
}
- (void)applicationWillEnterForeground:(UIApplication *)application {
    ZWWLog(@"\n即将进入前台\n applicationWillEnterForeground")
}
- (void)applicationDidBecomeActive:(UIApplication *)application {
    [[UIApplication alloc] setApplicationIconBadgeNumber:0];
    ZWWLog(@"\n程序开始启动\n applicationDidBecomeActive")
}
- (void)applicationWillTerminate:(UIApplication *)application {
    [ZWDataManager saveUserData];
    [[UIApplication alloc] setApplicationIconBadgeNumber:0];
    ZWWLog(@"\n 程序即将死掉 \n applicationWillTerminate")
}
+(UIViewController *)appRootViewController {
    UIViewController *appRootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (appRootVC.presentedViewController) {
        appRootVC = appRootVC.presentedViewController;
    }
    return appRootVC;
}
- (void)networkStatus:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    //2.根据权限执行相应的交互
    CTCellularData *cellularData = [[CTCellularData alloc] init];
    /*
     此函数会在网络权限改变时再次调用
     */
    cellularData.cellularDataRestrictionDidUpdateNotifier = ^(CTCellularDataRestrictedState state) {
        switch (state) {
            case kCTCellularDataRestricted:
                NSLog(@"Restricted");
                //2.1权限关闭的情况下 再次请求网络数据会弹出设置网络提示
                [self getAppInfo];
                break;
            case kCTCellularDataNotRestricted:
                NSLog(@"NotRestricted");
                //2.2已经开启网络权限 监听网络状态
                [self addReachabilityManager:application didFinishLaunchingWithOptions:launchOptions];
                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
            case kCTCellularDataRestrictedStateUnknown:
                NSLog(@"Unknown");
                //2.3未知情况 （还没有遇到推测是有网络但是连接不正常的情况下）
                [self getAppInfo];
                break;

            default:
                break;
        }
    };
}
- (void)addReachabilityManager:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    AFNetworkReachabilityManager *afNetworkReachabilityManager = [AFNetworkReachabilityManager sharedManager];
    [afNetworkReachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusNotReachable:{
                NSLog(@"网络不通：%@",@(status) );
                break;
            }
            case AFNetworkReachabilityStatusReachableViaWiFi:{
                NSLog(@"网络通过WIFI连接：%@",@(status));
                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
            }
            case AFNetworkReachabilityStatusReachableViaWWAN:{
                NSLog(@"网络通过无线连接：%@",@(status) );
                [self getInfo_application:application didFinishLaunchingWithOptions:launchOptions];
                break;
            }
            default:
                break;
        }
    }];
    [afNetworkReachabilityManager startMonitoring];  //开启网络监视器；
}
- (void)getInfo_application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    ///此时,手机已经获取到了网络..开始配置第三方服务
    //有网,添加自己的网络监测工具类
    NetworkStatus status = [self.reachablity currentReachabilityStatus];
    [self monitorNetworkStatus:status];
}
-(void)getAppInfo{
    ZWWLog(@"有网络,可以配置第三方")
    self.reachablity = [Reachability reachabilityWithHostName:@"https://www.baidu.com"];
    [self.reachablity startNotifier];
    NetworkStatus status = [self.reachablity currentReachabilityStatus];
    //网络监听
    [self monitorNetworkStatus:status];
    
}
-(void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
   
}
+ (AppDelegate *)shareAppDelegate{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}
@end
