

#import <UIKit/UIKit.h>

@interface BaseNavgationController : UINavigationController

@end
