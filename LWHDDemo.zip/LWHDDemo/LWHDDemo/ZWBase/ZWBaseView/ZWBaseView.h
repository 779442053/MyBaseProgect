//
//  ZWBaseView.h
//  EasyIM
//
//  Created by step_zhang on 2019/11/21.
//  Copyright © 2019 Looker. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "ZWBaseViewProtocal.h"
NS_ASSUME_NONNULL_BEGIN

@interface ZWBaseView : UIView<ZWBaseViewProtocal>

@end

NS_ASSUME_NONNULL_END
