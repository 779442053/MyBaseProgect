//
//  AppDelegate.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
+(UIViewController *)appRootViewController;
//单例
+ (AppDelegate *)shareAppDelegate;
@property (nonatomic,assign)BOOL allowRotation;
@end

