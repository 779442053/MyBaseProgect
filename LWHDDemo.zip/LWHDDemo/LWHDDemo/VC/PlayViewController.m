//
//  PlayViewController.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "PlayViewController.h"
#import "PlayerViewModel.h"
#import "PlayerModel.h"
#import <IJKMediaFramework/IJKMediaFramework.h>
#import "AppDelegate.h"
#import "ZWImageViewController.h"
@interface PlayViewController ()
@property (nonatomic, strong) PlayerViewModel *ViewModel;
@property(nonatomic,retain) id<IJKMediaPlayback> ijkPlayer; //播放器
@property (nonatomic, strong) UIView *container;
@property (nonatomic, assign) NSInteger currentTag;
@end

@implementation PlayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"云台控制"];
    [self showLeftBackButton];
    ZWWLog(@"播放地址 = %@",self.URL)
    //[self installMovieNotificationObservers];
    _container = [UIView new];
    [self.view addSubview:_container];
    self.container.frame = CGRectMake(0, ZWStatusAndNavHeight, KScreenWidth, 250);
    self.container.backgroundColor = [UIColor blackColor];
    #ifdef DEBUG
    //  设置报告日志
        [IJKFFMoviePlayerController setLogReport:YES];
    //  设置日志的级别为Debug
        [IJKFFMoviePlayerController setLogLevel:k_IJK_LOG_DEBUG];
    //1.2否则(如果不是debug状态的)
    #else
    //  设置不报告日志
        [IJKFFMoviePlayerController setLogReport:NO];
    //  设置日志级别为信息
        [IJKFFMoviePlayerController setLogLevel:k_IJK_LOG_INFO];
    #endif
    [IJKFFMoviePlayerController checkIfFFmpegVersionMatch:YES];
    IJKFFOptions *options = [IJKFFOptions optionsByDefault];
    [options setOptionIntValue:1 forKey:@"infbuf" ofCategory:kIJKFFOptionCategoryPlayer];
    [options setOptionIntValue:1024 forKey:@"maxx-buffer-size" ofCategory:kIJKFFOptionCategoryPlayer];
    [options setOptionValue:@"com.lewen.fastbig" forKey:@"rtmp_pageurl" ofCategory:kIJKFFOptionCategoryFormat];
    //底下这几句补上，可以大大提高ijkplayer打开直播流的速度
   [options setOptionIntValue:100L forKey:@"analyzemaxduration" ofCategory:1];
   [options setOptionIntValue:10240L forKey:@"probesize" ofCategory:1];
   [options setOptionIntValue:1L forKey:@"flush_packets" ofCategory:1];
   [options setOptionIntValue:0L forKey:@"packet-buffering" ofCategory:4];
   [options setOptionIntValue:1L forKey:@"framedrop" ofCategory:4];
    //设置rtmp的来源
    self.ijkPlayer = [[IJKFFMoviePlayerController alloc] initWithContentURL:[NSURL URLWithString:self.URL] withOptions:options];
    // 4.1 设置播放视频视图的frame与控制器的View的bounds一致
        self.ijkPlayer.view.frame = self.container.bounds;
    // 4.2 设置适配横竖屏(设置四边固定,长宽灵活)
        self.ijkPlayer.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    //  4.3 设置播放视图的缩放模式
        self.ijkPlayer.scalingMode = IJKMPMovieScalingModeAspectFill;
    //  4.4 设置自动播放
        self.ijkPlayer.shouldAutoplay = YES;
    //  4.5 自动更新子视图的大小
        self.view.autoresizesSubviews = YES;
    //  4.6 添加播放视图到控制器的View
    [self.container addSubview:self.ijkPlayer.view];
    [self zww_addSubviews];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if(![self.ijkPlayer isPlaying]){
        ZWWLog(@"==========准备播放")
        [self.ijkPlayer prepareToPlay];
    }
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    ZWWLog(@"关闭播放")
    [self.ijkPlayer shutdown];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:IJKMPMoviePlayerPlaybackStateDidChangeNotification object:self.ijkPlayer];
    self.ijkPlayer = nil;
}
-(void)Playering{
    ZWWLog(@"开始播放")
    [self.ijkPlayer play];
}
-(void)zww_addSubviews{
   NSArray *titles = @[@"左上",@"上",@"右上",@"左",@"开始",@"右",@"左下",@"下",@"右下",@"拍照",@"停止录像",@"获取字幕",@"全屏"];
    int maxCols = 3;
    float xMargin = 10;
    CGFloat buttonStartY = 255 + ZWStatusAndNavHeight;
    CGFloat buttonStartX = 20;
    CGFloat buttonW = (KScreenWidth - 2 * buttonStartX - xMargin * (maxCols - 1))/maxCols;
    CGFloat buttonH = 40;
    for (int i = 0; i < titles.count; i ++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitle:titles[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        button.tag = i;
        button.titleLabel.font = [UIFont systemFontOfSize:15];
        button.backgroundColor = [UIColor grayColor];
        [button addTarget:self action:@selector(ButtonClick:) forControlEvents:UIControlEventTouchDown];
        int col = i % maxCols;
        int row = i / maxCols;
        button.frame = CGRectMake(buttonStartX + col * (xMargin + buttonW), buttonStartY + row * (buttonH + 10), buttonW, buttonH);
        [self.view addSubview:button];
        }
   
   



[self.ijkPlayer prepareToPlay];
}
-(void)ButtonClick:(UIButton *)sender{
    ZWWLog(@"按下按钮")
    NSArray *titles = @[@"左上",@"上",@"右上",@"左",@"开始",@"右",@"左下",@"下",@"右下",@"拍照",@"停止录像",@"获取字幕",@"全屏"];
    NSArray *cmdARR = @[@"LEFT_UP",@"UP",@"RIGHT_UP",@"LEFT",@"开始",@"RIGHT",@"LEFT_DOWN",@"DOWN",@"RIGHT_DOWN",@"拍照",@"开始录像",@"获取字幕",@"全屏"];
    if (sender.tag == 12) {
        [self btnFullScreenDidClick:nil];
    }else if (sender.tag == 11){
        ZWWLog(@"获取字幕")
        
    }else if (sender.tag == 10){
        if (self.currentTag == sender.tag) {
            ZWWLog(@"停止录像")
            [sender setTitle:@"开始录像" forState:UIControlStateNormal];
            self.currentTag = 1000;
        }else{
            ZWWLog(@"开始录像")
            self.currentTag = sender.tag;
            [sender setTitle:@"停止录像" forState:UIControlStateNormal];
        }
    }else if (sender.tag == 9){
        ZWWLog(@"拍照")
       [[self.ViewModel.TakePicterCommand execute:@{@"devShortSerialNum":self.devShortSerialNum,@"stream":self.URL}]subscribeNext:^(id  _Nullable x) {
           if ([x[@"code"] intValue] == 0) {
               ZWWLog(@"照片 = %@",x[@"url"])
               ZWImageViewController *imageViewC =[[ZWImageViewController alloc] init];
               imageViewC.imageData = x[@"url"];
               [self presentViewController:imageViewC animated:YES completion:nil];
           }
        }];
        
    }else if (sender.tag == 4){
        ZWWLog(@"开始===不作处理 ")
        
    }else{
        if (self.currentTag != sender.tag) {
            [sender setTitle:@"停止" forState:UIControlStateNormal];
             self.currentTag = sender.tag;
            ZWWLog(@"开始出发cmd")
            NSString *cmd = cmdARR[sender.tag];
            [[self.ViewModel.CommandrequestCommand execute:@{@"devShortSerialNum":self.devShortSerialNum,@"cmd":cmd}] subscribeNext:^(id  _Nullable x) {
                if ([x[@"code"] intValue] == 0) {
                    ZWWLog(@"成功")
                }
            }];
        }else{
            ZWWLog(@"结束cmd")
            [sender setTitle:titles[sender.tag] forState:UIControlStateNormal];
            self.currentTag = 1000;
            NSString *cmd = cmdARR[sender.tag];
            [[self.ViewModel.CommandStopCommand execute:@{@"devShortSerialNum":self.devShortSerialNum,@"cmd":cmd}] subscribeNext:^(id  _Nullable x) {
                if ([x[@"code"] intValue] == 0) {
                    ZWWLog(@"停止成功")
                }
            }];
        }
    }
}


-(void)zw_bindViewModel{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    appDelegate.allowRotation = YES;
}
#pragma mark - 与全屏相关的代理方法等

BOOL fullScreen;

static UIButton * btnFullScreen;

//点击了全屏按钮
-(void)btnFullScreenDidClick:(UIButton *)sender{

    fullScreen = !fullScreen;

    btnFullScreen = sender;

    if (fullScreen) {//小屏->全屏
        [UIView animateWithDuration:0.25 animations:^{
            NSNumber * value  = [NSNumber numberWithInt:UIInterfaceOrientationLandscapeRight];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }];

    }else{//全屏->小屏
        [UIView animateWithDuration:0.25 animations:^{
            NSNumber * value  = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }];
    }
}

- (void)statusBarOrientationChange:(NSNotification *)notification
{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationLandscapeRight) // home键靠右
    {
        fullScreen = YES;

        [UIView animateWithDuration:0.25 animations:^{
            self.container.frame = CGRectMake(0, 0, KScreenHeight, KScreenWidth);
            self.ijkPlayer.view.frame = CGRectMake(0, 0, KScreenHeight, KScreenWidth);
        }];
    }

    if (orientation ==UIInterfaceOrientationLandscapeLeft) // home键靠左
    {
        fullScreen = YES;

        [UIView animateWithDuration:0.25 animations:^{
            self.container.frame = CGRectMake(0, 0, KScreenWidth, KScreenHeight);
            self.ijkPlayer.view.frame = CGRectMake(0, 0, KScreenWidth, KScreenHeight);
        }];
    }
    if (orientation == UIInterfaceOrientationPortrait)
    {
        fullScreen = NO;

        [UIView animateWithDuration:0.25 animations:^{
            self.container.transform= CGAffineTransformMakeRotation(0);
            self.ijkPlayer.view.frame = self.container.frame;
        }];
    }
    if (orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        NSLog(@"其他");
    }
}

-(void)dealloc{
    NSLog(@"+++++++++++++delloc+++++++++++");
    [self.ijkPlayer shutdown];
    self.ijkPlayer = nil;
}
-(PlayerViewModel *)ViewModel{
    if (_ViewModel == nil) {
        _ViewModel = [[PlayerViewModel alloc]init];
    }
    return _ViewModel;;
}
@end
