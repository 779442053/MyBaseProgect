//
//  ListVC.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ListVC.h"
#import "ZWListViewModel.h"
#import "ListCell.h"
#import "PlayViewController.h"
#import "PlayerModel.h"
@interface ListVC ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *dataArray;
@property(nonatomic,strong)ZWListViewModel *ViewModel;
@end

@implementation ListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)zw_bindViewModel{
    @weakify(self);
    [[self.ViewModel.requestCommand execute:nil] subscribeNext:^(NSDictionary * x) {
        @strongify(self);
        ZWWLog(@"设备列表=%@",x)
        if ([x[@"code"] intValue] == 0) {
            self.dataArray = [ZWListModel mj_objectArrayWithKeyValuesArray:x[@"ret"]];
            [self.tableView reloadData];
        }
    }];
}
-(void)zw_addSubviews{
    [self setTitle:@"设备列表"];
    [self showLeftBackButton];
    [self.view addSubview:self.tableView];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ZWListModel *model = self.dataArray[indexPath.row];
    [ZWSaveTool setObject:model.cameraName forKey:@"cameraName"];
    [ZWSaveTool setObject:model.devShortSerialNum forKey:@"devShortSerialNum"];
    [[self.ViewModel.GetUrlCommand execute:@{@"cameraName":model.cameraName,@"devShortSerialNum":model.devShortSerialNum}] subscribeNext:^(id  _Nullable x) {
        if ([x[@"code"] intValue] == 0) {
            PlayerModel *Model = x[@"res"];
            //回到主线程
            dispatch_async(dispatch_get_main_queue(), ^{
              PlayViewController *VC = [[PlayViewController alloc]init];
              VC.URL = Model.url;
              VC.devShortSerialNum = model.devShortSerialNum;
              VC.cameraName = model.cameraName;
              [self.navigationController pushViewController:VC animated:YES];
            });
            
        }
    }];
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
     ListCell*cell   = [tableView dequeueReusableCellWithIdentifier:@"ListCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[ListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ListCell"];
    }
    ZWListModel *address             = self.dataArray[indexPath.row];
    [cell updateAddress:address];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 90.0f;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

-(ZWListViewModel *)ViewModel{
    if (_ViewModel == nil) {
        _ViewModel = [[ZWListViewModel alloc]init];
    }
    return _ViewModel;
}
- (NSMutableArray *)dataArray
{
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}
- (UITableView *)tableView
{
    if (!_tableView)
    {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 10 + ZWStatusAndNavHeight, KScreenWidth, KScreenHeight - 10 - ZWStatusAndNavHeight) style:UITableViewStylePlain];
        self.tableView.dataSource       = self;
        self.tableView.delegate         = self;
        self.tableView.backgroundColor  = [UIColor colorWithHexString:@"FBFAF8"];
        self.tableView.separatorStyle   = UITableViewCellSeparatorStyleNone;
        [self.tableView registerClass:[ListCell class] forCellReuseIdentifier:@"ListCell"];
    }
    return _tableView;
}
@end
