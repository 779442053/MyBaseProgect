//
//  PlayViewController.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "MMBaseViewController.h"
#import "ZWListModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface PlayViewController : MMBaseViewController
@property(nonatomic,copy)NSString *IP;
@property(nonatomic,copy)NSString *devShortSerialNum;
@property(nonatomic,copy)NSString *cameraName;
@property(nonatomic,copy)NSString *URL;
@end

NS_ASSUME_NONNULL_END
