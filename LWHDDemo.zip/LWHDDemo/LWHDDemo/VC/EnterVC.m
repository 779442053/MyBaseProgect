//
//  EnterVC.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "EnterVC.h"
#import "ListVC.h"
#import "ZWListViewModel.h"
#import "PlayerModel.h"
#import "PlayViewController.h"
@interface EnterVC ()
@property(nonatomic,strong)ZWListViewModel *ViewModel;
@end

@implementation EnterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.IPTextFlb.text = @"http://139.159.239.188";
    
    
}
-(void)zw_addSubviews{
    [self setTitle:@"HDDemo"];
}

- (IBAction)StardBtn:(UIButton *)sender {
    if (self.NumTF.text.length != 0) {
        [[self.ViewModel.GetUrlCommand execute:@{@"cameraName":self.NameTF.text,@"devShortSerialNum":self.NumTF.text}] subscribeNext:^(id  _Nullable x) {
            if ([x[@"code"] intValue] == 0) {
                PlayerModel *Model = x[@"res"];
                dispatch_async(dispatch_get_main_queue(), ^{
                  PlayViewController *VC = [[PlayViewController alloc]init];
                  VC.URL = Model.url;
                  VC.devShortSerialNum = self.NumTF.text;
                  VC.cameraName = self.NameTF.text;
                  [self.navigationController pushViewController:VC animated:YES];
                });
                
            }else{
                [MMProgressHUD showHUD:@"设备编号错误" withDelay:1.5];
            }
        }];
    }else{
        [MMProgressHUD showHUD:@"请输入设备编号" withDelay:1.5];
    }
}
- (IBAction)LishBtnClick:(UIButton *)sender {
    [self.navigationController pushViewController:[ListVC new] animated:YES];
}
-(ZWListViewModel *)ViewModel{
    if (_ViewModel == nil) {
        _ViewModel = [[ZWListViewModel alloc]init];
    }
    return _ViewModel;
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([ZWSaveTool objectForKey:@"cameraName"]) {
        self.NameTF.text = [ZWSaveTool objectForKey:@"cameraName"];
        self.NumTF.text = [ZWSaveTool objectForKey:@"devShortSerialNum"];
    }
}
@end
