//
//  ZWImageViewController.m
//  LWHDDemo
//
//  Created by step_zhang on 2020/5/8.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ZWImageViewController.h"

@interface ZWImageViewController ()

@end

@implementation ZWImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    
    UITapGestureRecognizer *taps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismisTaps)];
    [self.view addGestureRecognizer:taps];
    UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 400)];
    imageV.center = self.view.center;
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:self.imageData]];
    imageV.image = [UIImage imageWithData:data];
    [self.view addSubview:imageV];
}
- (void)dismisTaps{
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
