//
//  ZWListModel.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ZWBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZWListModel : ZWBaseModel
@property(nonatomic,copy)NSString *cameraName;
@property(nonatomic,copy)NSString *devShortSerialNum;
@property(nonatomic,copy)NSString *cameraIndexCode;
@property(nonatomic,copy)NSString *gbIndexCode;
@property(nonatomic,copy)NSString *transType;
@property(nonatomic,copy)NSString *devSerialNum;
@property(nonatomic,copy)NSString *regionIndexCode;
@property(nonatomic,copy)NSString *encodeDevIndexCode;
@property(nonatomic,copy)NSString *updateTime;
//@property(nonatomic,copy)NSString *transType;
//@property(nonatomic,copy)NSString *transType;
@end

NS_ASSUME_NONNULL_END
