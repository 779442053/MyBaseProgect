//
//  PlayerModel.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ZWBaseModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PlayerModel : ZWBaseModel
@property(nonatomic,copy)NSString *url;
@property(nonatomic,copy)NSString *devShortSerialNum;
@end

NS_ASSUME_NONNULL_END
