//
//  main.m
//  LWHDDemo
//
//  Created by step_zhang on 2020/5/7.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
