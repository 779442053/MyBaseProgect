//
//  ZWListViewModel.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ZWListViewModel.h"
#import "ZWListModel.h"
#import "PlayerModel.h"
@implementation ZWListViewModel
-(void)zw_initialize{
    @weakify(self);
    self.requestCommand = [[RACCommand alloc] initWithSignalBlock:^RACSignal *(id input) {
        return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
            @strongify(self)
            //[YJProgressHUD showLoading:@"请求中..."];
            //[MMProgressHUD showHUD];
            [self.request GET:Login parameters:nil success:^(ZWRequest *request, NSMutableDictionary *responseObject, NSDictionary *data) {
                //[MMProgressHUD ];
                ZWWLog(@"==%@  ==%@",responseObject,data);
                if ([responseObject[@"code"] intValue] == 0) {
                    NSArray *arr = responseObject[@"data"][@"list"];
                    [subscriber sendNext:@{@"code":@"0",@"ret":arr}];
                    [subscriber sendCompleted];
                }else if ([responseObject[@"status"] intValue] == 2){
                    //[MMProgressHUD showError:responseObject[@"msg"]];
                    [subscriber sendNext:@{@"code":@"2"}];
                    [subscriber sendCompleted];
                }else{
                    //[MMProgressHUD showError:responseObject[@"msg"]];
                    [subscriber sendNext:@{@"code":@"1"}];
                    [subscriber sendCompleted];
                }
            } failure:^(ZWRequest *request, NSError *error) {
//                [MMProgressHUD hideHUD];
//                [MMProgressHUD showError:@"获取失败,稍后再来"];
                [subscriber sendError:error];
                [subscriber sendCompleted];
            }];
            return [RACDisposable disposableWithBlock:^{
            }];
        }];
    }];
    
    self.GetUrlCommand = [[RACCommand alloc] initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
         return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                   @strongify(self)
                   //[YJProgressHUD showLoading:@"请求中..."];
             NSMutableDictionary *Parma = [[NSMutableDictionary alloc]init];
             Parma[@"cameraName"] = input[@"cameraName"];
             Parma[@"devShortSerialNum"] = input[@"devShortSerialNum"];
             [self.request POST:Regist parameters:Parma success:^(ZWRequest *request, NSMutableDictionary *responseObject, NSDictionary *data) {
                         //[YJProgressHUD hideHUD];
                         ZWWLog(@"==%@  ==%@",responseObject,data);
                         if ([responseObject[@"code"] intValue] == 0) {
                             PlayerModel *Model = [PlayerModel mj_objectWithKeyValues:responseObject[@"data"]];
                             [subscriber sendNext:@{@"code":@"0",@"res":Model}];
                             [subscriber sendCompleted];
                         }else if ([responseObject[@"status"] intValue] == 2){
                             //[YJProgressHUD showError:responseObject[@"msg"]];
                             [subscriber sendNext:@{@"code":@"2"}];
                             [subscriber sendCompleted];
                         }else{
                             //[YJProgressHUD showError:responseObject[@"msg"]];
                             [subscriber sendNext:@{@"code":@"1"}];
                             [subscriber sendCompleted];
                         }
                     } failure:^(ZWRequest *request, NSError *error) {
//                         [YJProgressHUD hideHUD];
//                         [YJProgressHUD showError:@"获取失败,稍后再来"];
                         [subscriber sendError:error];
                         [subscriber sendCompleted];
                     }];
                     return [RACDisposable disposableWithBlock:^{
                     }];
         }];
    }];
}
@end
