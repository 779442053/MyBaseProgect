//
//  PlayerViewModel.m
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "PlayerViewModel.h"
#import "PlayerModel.h"
@implementation PlayerViewModel
-(void)zw_initialize{
     @weakify(self);
    self.requestCommand = [[RACCommand alloc] initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
         return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                   @strongify(self)
                   //[ showLoading:@"请求中..."];
             NSMutableDictionary *Parma = [[NSMutableDictionary alloc]init];
             Parma[@"cameraName"] = input[@"cameraName"];
             Parma[@"devShortSerialNum"] = input[@"devShortSerialNum"];
             [self.request POST:Regist parameters:Parma success:^(ZWRequest *request, NSMutableDictionary *responseObject, NSDictionary *data) {
                         //[YJProgressHUD hideHUD];
                         ZWWLog(@"==%@  ==%@",responseObject,data);
                         if ([responseObject[@"code"] intValue] == 0) {
                             PlayerModel *Model = [PlayerModel mj_objectWithKeyValues:responseObject[@"data"]];
                             [subscriber sendNext:@{@"code":@"0",@"ret":Model}];
                             [subscriber sendCompleted];
                         }else if ([responseObject[@"status"] intValue] == 2){
                             //[YJProgressHUD showError:responseObject[@"msg"]];
                             [subscriber sendNext:@{@"code":@"2"}];
                             [subscriber sendCompleted];
                         }else{
                             //[YJProgressHUD showError:responseObject[@"msg"]];
                             [subscriber sendNext:@{@"code":@"1"}];
                             [subscriber sendCompleted];
                         }
                     } failure:^(ZWRequest *request, NSError *error) {
//                         [YJProgressHUD hideHUD];
//                         [YJProgressHUD showError:@"获取失败,稍后再来"];
                         [subscriber sendError:error];
                         [subscriber sendCompleted];
                     }];
                     return [RACDisposable disposableWithBlock:^{
                     }];
         }];
    }];
    /**
     不区分大小写
     LEFT 左转
     RIGHT右转
     UP 上转
     DOWN 下转
     ZOOM_IN 焦距变大
     ZOOM_OUT 焦距变小
     LEFT_UP 左上
     LEFT_DOWN 左下
     RIGHT_UP 右上
     RIGHT_DOWN 右下
     FOCUS_NEAR 焦点前移
     FOCUS_FAR 焦点后移
     IRIS_ENLARGE 光圈扩大
     IRIS_REDUCE 光圈缩小；
     以下命令presetIndex不可为空：
     GOTO_PRESET到预置点
     */
    self.CommandrequestCommand = [[RACCommand alloc] initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
         @strongify(self)
         NSMutableDictionary *Parma = [[NSMutableDictionary alloc]init];
            Parma[@"action"] = @"0";
            Parma[@"devShortSerialNum"] = input[@"devShortSerialNum"];
            Parma[@"command"] = input[@"cmd"];
         [self.request POST:@":1999/hk_api?cmd=ptzAction" parameters:Parma success:^(ZWRequest *request, NSMutableDictionary *responseObject, NSDictionary *data) {
                ZWWLog(@"==%@  ==%@",responseObject,data);
                if ([responseObject[@"code"] intValue] == 0) {
                  [subscriber sendNext:@{@"code":@"0"}];
                  [subscriber sendCompleted];
                }else{
                  [subscriber sendNext:@{@"code":@"1"}];
                  [subscriber sendCompleted];
                }
                 } failure:^(ZWRequest *request, NSError *error) {
                     [subscriber sendError:error];
                     [subscriber sendCompleted];
                 }];
                 return [RACDisposable disposableWithBlock:^{
                 }];
             }];
        }];
    self.CommandStopCommand = [[RACCommand alloc] initWithSignalBlock:^RACSignal *(id input) {
            return [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
                @strongify(self)
                NSMutableDictionary *Parma = [[NSMutableDictionary alloc]init];
               Parma[@"action"] = @"1";
               Parma[@"devShortSerialNum"] = input[@"devShortSerialNum"];
               Parma[@"command"] = input[@"cmd"];
                [self.request POST:@":1999/hk_api?cmd=ptzAction" parameters:Parma success:^(ZWRequest *request, NSMutableDictionary *responseObject, NSDictionary *data) {
                    ZWWLog(@"==%@  ==%@",responseObject,data);
                    if ([responseObject[@"code"] intValue] == 0) {
                        [subscriber sendNext:@{@"code":@"0"}];
                        [subscriber sendCompleted];
                    }else{
                        [subscriber sendNext:@{@"code":@"1"}];
                        [subscriber sendCompleted];
                    }
                } failure:^(ZWRequest *request, NSError *error) {
                    [subscriber sendError:error];
                    [subscriber sendCompleted];
                }];
                return [RACDisposable disposableWithBlock:^{
                }];
            }];
        }];
    //拍照
    self.TakePicterCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal * _Nonnull(id  _Nullable input) {
        return [RACSignal createSignal:^RACDisposable * _Nullable(id<RACSubscriber>  _Nonnull subscriber) {
            @strongify(self)
             NSMutableDictionary *Parma = [[NSMutableDictionary alloc]init];
              Parma[@"devShortSerialNum"] = input[@"devShortSerialNum"];
              Parma[@"stream"] = input[@"stream"];
             [self.request POST:@":1999/hk_api?cmd=snapshot" parameters:Parma success:^(ZWRequest *request, NSMutableDictionary *responseObject, NSDictionary *data) {
                 ZWWLog(@"==%@  ==%@",responseObject,data);
                 if ([responseObject[@"code"] intValue] == 0) {
                     [subscriber sendNext:@{@"code":@"0",@"url":responseObject[@"data"][@"url"]}];
                     [subscriber sendCompleted];
                 }else{
                     [subscriber sendNext:@{@"code":@"1"}];
                     [subscriber sendCompleted];
                 }
             } failure:^(ZWRequest *request, NSError *error) {
                 [subscriber sendError:error];
                 [subscriber sendCompleted];
             }];
            
            
            
            return [RACDisposable disposableWithBlock:^{
                
            }];
        }];
    }];
    
}
@end
