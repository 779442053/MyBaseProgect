//
//  ZWListViewModel.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ZWBaseViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZWListViewModel : ZWBaseViewModel
@property(nonatomic,strong)RACCommand       *requestCommand;
@property(nonatomic,strong)RACCommand       *GetUrlCommand;
@end

NS_ASSUME_NONNULL_END
