//
//  PlayerViewModel.h
//  HDDemo
//
//  Created by step_zhang on 2020/5/6.
//  Copyright © 2020 step_zhang. All rights reserved.
//

#import "ZWBaseViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface PlayerViewModel : ZWBaseViewModel
@property(nonatomic,strong)RACCommand       *requestCommand;
@property(nonatomic,strong)RACCommand       *CommandrequestCommand;
@property(nonatomic,strong)RACCommand       *CommandStopCommand;
//拍照
@property(nonatomic,strong)RACCommand       *TakePicterCommand;

@end

NS_ASSUME_NONNULL_END
