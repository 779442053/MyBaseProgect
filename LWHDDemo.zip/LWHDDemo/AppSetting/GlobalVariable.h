///
//  GlobalVariable.h
//  speedauction
//
//  Created by yuanku on 15/9/17.
//  Copyright (c) 2015年 Company. All rights reserved.
//

#ifndef speedauction_GlobalVariable_h
#define speedauction_GlobalVariable_h

#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_IOS_11  ([[[UIDevice currentDevice] systemVersion] floatValue] >= 11.f)
#define G_SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
//屏幕高
#define G_SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define G_UI_WIDTH (G_SCREEN_WIDTH - 2 * G_UI_START_X)
//宽度比例适配
#define G_GET_SCALE_LENTH(a)  a/720.0f*G_SCREEN_WIDTH*2.0
//高度比例适配
#define G_GET_SCALE_HEIGHT(a)  a/1280.0f*G_SCREEN_HEIGHT*2.0
///判断设备类型是否iPhoneX
#define ISIphoneX  (IS_IOS_11 && IS_IPHONE && (MIN([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) >= 375 && MAX([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) >= 812))
//主题色
#define G_EEF0F3_COLOR [UIColor colorWithHexString:@"eef0f3"]//线颜色
#define FONT(f) [UIFont fontWithName:@"MicrosoftYaHei" size:f]
#define K_DEFAULT_USER_PIC [UIImage imageNamed:@"setting_default_icon"]

//MARK: - fir.im 版本检测
////////////////////////////////////////////////////////////////////////////////
#define K_APP_FIR_IM_URL @"https://api.fir.im/apps/latest/5d5e356b23389f1248bd3064"

//fir.im token
#define K_APP_FIR_IM_TOKEN @"c8e3b5b088c7ab9aa73807b518ec9c29"
#define K_APP_REQUEST_PLATFORM @"IOS"

//MARK: - GCDSocketTCPCMD 枚举
typedef NS_ENUM(NSUInteger,MMConGroupItem){
    MMConGroup_Friend = 0,
    MMConGroup_Group,
    MMConGroup_Topic,
};
//枚举,具有一定顺序或者自定义顺序.....需要修改
typedef NS_ENUM(NSInteger,GCDSocketTCPCmdType){
    /** heartBeat 心跳包 */
    GCDSocketTCPCmdTypeHeartBeat = 0,
    /** updateuserstate 下线通知 */
    GCDSocketTCPCmdTypeupdateUserStatus,
    /** friendStatus 好友上线通知 */
    GCDSocketTCPCmdTypeFriendStatus,
    /** inviteFrd2Group 邀请好友入群 */
    GCDSocketTCPCmdTypeInviteFrd2Group,
    /**邀请好友之后,其他成员受到消息*/
    GCDSocketTCPCmdTypenewMember2Group,
    /** hasBulletin 好友通知 */
    GCDSocketTCPCmdTypeHasBulletin,
    GCDSocketTCPCmdTypeCallUser,
    GCDSocketTCPCmdTypeCallGroup,
    /** login 获取登陆消息 */
    GCDSocketTCPCmdTypeLogin,
    /** sendMsg 发送消息回调 */
    GCDSocketTCPCmdTypeSendMsg,
    /** fetchMsg 读取消息 接受到聊天消息 */
    GCDSocketTCPCmdTypeFetchMsg,
    /** HangUpCall 挂断 */
    GCDSocketTCPCmdTypeHangUpCall,
    /** 接受音视频邀请(AcceptCall 1v1、AcceptGroupCall 1vM) */
    GCDSocketTCPCmdTypeAcceptCall,
    GCDSocketTCPCmdTypeAcceptGroupCall,
    /** 拒绝视频邀请(RejectCall 1v1、RejectGroupCall 1vM) */
    GCDSocketTCPCmdTypeRejectCall,
    GCDSocketTCPCmdTypeRejectGroupCall,
    /** fetchGroupMsg 读取群消息 */
    GCDSocketTCPCmdTypeFetchGroupMsg,
    /** checkUserOnline 检查用户是否在线 */
    GCDSocketTCPCmdTypeCheckUserOnline,
    /** groupMsg 发群消息回调 */
    GCDSocketTCPCmdTypeGroupMsg,
    /** addFriend 加好友回调 */
    GCDSocketTCPCmdTypeAddFriend,
    /** deleteGroup 解散群回调 */
    GCDSocketTCPCmdTypeDeleteGroup,
    /** exitGroup 退出群回调 */
    GCDSocketTCPCmdTypeExitGroup,
    /** joinChatRoom 加入聊天室 */
    GCDSocketTCPCmdTypeJoinChatRoom,
    /** exitChatRoom 离开聊天室 */
    GCDSocketTCPCmdTypeExitChatRoom,
    /** sendChatRoomMsg 聊天室发送消息/礼物/红包 */
    GCDSocketTCPCmdTypeSendChatRoomMsg,
    /** logout 退出登录 */
    GCDSocketTCPCmdTypeLogout,
    /** 撤回消息 */
    GCDSocketTCPCmdTyperevokeMsg,
    /**群主踢人*/
    GCDSocketTCPCmdTypekickGroupMember,
    /**群主同意申请人加入本群*/
    GCDSocketTCPCmdTypeagreeJoinGroup,
    /**群主拒绝申请人加入本群*/
    GCDSocketTCPCmdTyperejectJoinGroup,
    /**创建群*/
    GCDSocketTCPCmdTyperejectaddGroup,
    /**接受好友的添加请求*/
    GCDSocketTCPCmdTypeacceptFriend,
    /**拒绝好友的添加请求*/
    GCDSocketTCPCmdTyperejectFriend,
    /**加入本群*/
    GCDSocketTCPCmdTypejoinGroup,
    /**忽略通知*/
    GCDSocketTCPCmdTypeignoreBulletin,
    /**delFriend 删除好友*/
    GCDSocketTCPCmdTypedelFriend,
    /**呼叫会话心跳（会话建立后发送，每隔60s）*/
    GCDSocketTCPCmdTypecallHeartbeat,
    /**接受邀请*/
    GCDSocketTCPCmdTypeacceptJoinGroup,
    /**退出群,删除群,删除好友,等等,相关通知*/
    GCDSocketTCPCmdTypefetchBulletin,
    /**群消息变更*/
    GCDSocketTCPCmdTypeupdateGroupInfo,
    /**群呼叫挂断*/
    GCDSocketTCPCmdTypeHangupGroupCall,
    /**音视频切换*/
    GCDSocketTCPCmdTypeSwitchGroupAVTalk,
    /**恢复音视频*/
    GCDSocketTCPCmdTypeRecoverGroupCall,
    /**好友消息变更*/
    GCDSocketTCPCmdTypeUpdateFriendInfo,
    /**群消息撤回*/
    GCDSocketTCPCmdTyperevokeGroupMsg,
};

#define ZWGCDSocketTCPCmdTypeGet @[@"heartBeat",\
@"updateUserStatus",\
@"friendStatus",\
@"inviteFrd2Group",\
@"newMember2Group",\
@"hasBulletin",\
@"callUser",\
@"CallGroup",\
@"login",\
@"sendMsg",\
@"fetchMsg",\
@"HangUpCall",\
@"AcceptCall",\
@"AcceptGroupCall",\
@"RejectCall",\
@"RejectGroupCall",\
@"fetchGroupMsg",\
@"checkUserOnline",\
@"groupMsg",\
@"addFriend",\
@"deleteGroup",\
@"exitGroup",\
@"joinChatRoom",\
@"exitChatRoom",\
@"sendChatRoomMsg",\
@"logout",\
@"revokeMsg",\
@"kickGroupMember",\
@"agreeJoinGroup",\
@"rejectJoinGroup",\
@"addGroup",\
@"acceptFriend",\
@"rejectFriend",\
@"joinGroup",\
@"ignoreBulletin",\
@"delFriend",\
@"callHeartbeat",\
@"acceptJoinGroup",\
@"fetchBulletin",\
@"updateGroupInfo",\
@"HangupGroupCall",\
@"SwitchGroupAVTalk",\
@"RecoverGroupCall",\
@"updateFriendInfo",\
@"revokeGroupMsg",]

/** 枚举 to 字串 */
#define ZWGCDSocketTCPCmdTypeString(type) ([ZWGCDSocketTCPCmdTypeGet objectAtIndex:type])

/** 字串 to 枚举 */
#define ZWGCDSocketTCPCmdTypeEnum(string) ([ZWGCDSocketTCPCmdTypeGet indexOfObject:string])


#endif
